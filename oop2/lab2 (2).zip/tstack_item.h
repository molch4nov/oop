#ifndef TSTACK_ITEM_H
#define TSTACK_ITEM_H

#include "triangle.h"

class TStackItem {
public:
  TStackItem(const Triangle& triangle);
  TStackItem(const TStackItem& other);
  
  TStackItem* SetNext(TStackItem* next);
  TStackItem* GetNext();

  Triangle GetTriangle() const;
 
  friend std::ostream& operator<<(std::ostream& os, const TStackItem& obj);

  virtual ~TStackItem();

private:
  Triangle triangle;
  TStackItem *next;
};
 
#endif // TSTACK_ITEM_H
