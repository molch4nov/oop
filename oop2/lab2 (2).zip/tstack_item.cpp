#include "tstack_item.h"
#include "triangle.h"

#include <iostream>

TStackItem::TStackItem(const Triangle& triangle) {
  this->triangle = triangle;
  this->next = nullptr;
  std::cout << "Stack item: created" << std::endl;
}
 
TStackItem::TStackItem(const TStackItem& other) {
  this->triangle = other.triangle;
  this->next = other.next;
  std::cout << "Stack item: copied" << std::endl;
}
 
TStackItem* TStackItem::SetNext(TStackItem* next) {
  TStackItem* prev = this->next;
  this->next = next;
  return prev;
}
 
Triangle TStackItem::GetTriangle() const {
  return this->triangle;
}
 
TStackItem* TStackItem::GetNext() {
  return this->next;
}
 
TStackItem::~TStackItem() {
  std::cout << "Stack item: deleted" << std::endl;
  delete next;
}
 
std::ostream& operator<<(std::ostream& os, const TStackItem& obj) {
  os << "Item: " << obj.triangle << std::endl;
  return os;
}
