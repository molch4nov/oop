#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <iostream>

class Triangle {
public:
  Triangle();
  Triangle(double a, double b, double c);
  Triangle(const Triangle& other);

  double Area();

  friend std::istream& operator>>(std::istream& is,  Triangle& obj);
  friend std::ostream& operator<<(std::ostream& os, const Triangle& obj);

  Triangle& operator++();
  friend Triangle operator+(const Triangle& left, const Triangle& right); 

  Triangle& operator=(const Triangle& other);

  virtual ~Triangle();

private:
  double side_a;
  double side_b;
  double side_c;
};

#endif // TRIANGLE_H
