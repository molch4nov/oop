#include "triangle.h"

#include <iostream>
#include <cmath>

Triangle::Triangle()
    : side_a(0.0), side_b(0.0), side_c(0.0) {
  std::cout << "Default triangle created" << std::endl;
}

Triangle::Triangle(double a, double b, double c)
    : side_a(a), side_b(b), side_c(c) {
  std::cout << "Triangle created: " << side_a << ", " << side_b << ", " << side_c << std::endl;
}

std::istream& operator>>(std::istream& is, Triangle& obj) {
  is >> obj.side_a >> obj.side_b >> obj.side_c;
  return is;
}

Triangle::Triangle(const Triangle& other)
    : Triangle(other.side_a, other.side_b, other.side_c) {
  std::cout << "Triangle copy created" << std::endl;
}

double Triangle::Area() {
  double p = (side_a + side_b + side_c) / 2.0;
  return std::sqrt(p * (p - side_a) * (p - side_b) * (p - side_c));
}

Triangle& Triangle::operator=(const Triangle& other) {
  if (this == &other)
    return *this;

  side_a = other.side_a;
  side_b = other.side_b;
  side_c = other.side_c;

  std::cout << "Triangle copied" << std::endl;
  
  return *this;
}

Triangle& Triangle::operator++() {
  side_a += 1.0;
  side_b += 1.0;
  side_c += 1.0;
  
  return *this;
}

Triangle operator+(const Triangle& l, const Triangle& r) {
  return Triangle(l.side_a + r.side_a, l.side_b + r.side_b,l.side_c + r.side_c);
}

std::ostream& operator<<(std::ostream& os, const Triangle& obj) {
  os << "a = " << obj.side_a << ", ";
  os << "b = " << obj.side_b << ", ";
  os << "c = " << obj.side_c << std::endl;
  return os;
}

Triangle::~Triangle() {
  std::cout << "Triangle deleted" << std::endl;
}
